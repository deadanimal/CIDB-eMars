﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MAT.WebApp.App.Reports
{
    public partial class SR001 : WebApp.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                getYear();
                getQuarter();
            }
        }
        private void getYear()
        {
            DataSet dsYear = DataLayer.GetDataSet("SP_Year");
            ddlYear.DataSource = dsYear.Tables[0];
            ddlYear.DataValueField = "Year";
            ddlYear.DataTextField = "Year";
            ddlYear.DataBind();
            ddlYear.SelectedValue = Convert.ToString((DateTime.Now.Year));
        }
        private void getQuarter()
        {
            DataSet dsQuarter = DataLayer.GetDataSet("SP_Quarter");
            ddlQuarter.DataSource = dsQuarter.Tables[0];
            ddlQuarter.DataTextField = "Quarter";
            ddlQuarter.DataValueField = "QuarterNO";
            ddlQuarter.DataBind();
        }
        private string GetReportsHTML(string Year, string Quarter)
        {
            try
            {

                StringBuilder sbDiv = new StringBuilder();

                //sbDiv.AppendLine("<style type='text/css'>");
                //sbDiv.AppendLine("div {padding: 5px;}	#KPIParentDiv {	border: 0.5px dotted;}	#KPIDiv {	}	#divTHRUST_CODE:before {content: 'Thrust: ';}	#divTHRUST_CODE {display: inline;}	#divTHRUST_DESC {display: inline;}	#divINITIATIVE_CODE:before {content: 'Initiative: ';}	#divINITIATIVE_CODE {display: inline;}	#divINITIATIVE_DESC {display: inline;}	#divSUB_INITIATIVE_DESC {display: none;	}	#divSUB_INITIATIVE_CODE {display: none;} #divKPI_CODE:before {content: 'KPI: ';}	#divKPI_CODE {display: inline;background-color:black;}	#divKPI_DESC {display: inline;}	#divCUM_KPI_TARGET:before {	content: 'Target: ';}	#divCUM_KPI_PROGRESS:before {content: 'Progress: ';}#divCUM_KPI_PERCENTAGE:before {content: 'Achievement: ';}	#divCUM_KPI_PERCENTAGE:after {		content: ' % ';	}	#divKPI_LEADER_NAME1 {		display: none;	}	#divOWNER_NAME:before {		content: 'Owner: ';	}	#divSPONSOR_NAME:before {		content: 'Sponsor: ';	}	#divOIC_NAME:before {		content: 'OIC: ';	}	#divSPONSOR_NAME:before {		content: 'Sponsor: ';	}'");
                //sbDiv.AppendLine("</style>");



                //StringBuilder sb1 = new StringBuilder();
                // sb1.AppendLine("WITH A AS (SELECT DISTINCT C.[YEAR],C.[QUARTER],C.THRUST_CODE,D.THRUST_DESC,C.INITIATIVE_CODE,D.INITIATIVE_DESC   ,C.SUB_INITIATIVE_CODE,D.[SUB_INITIATIVE_DESC],C.KPI_CODE	  ,D.KPI_DESC ,D.ID,CUM_KPI_TARGET,CUM_KPI_PROGRESS,CAST(ROUND(CUM_KPI_PERCENTAGE, 0) AS INT) 'CUM_KPI_PERCENTAGE' FROM CUMULATIVE C LEFT JOIN VW_DIM_KPI D ON C.KPI_CODE = D.KPI_CODE AND C.YEAR = D.YEAR AND C.QUARTER = D.Quarter LEFT JOIN FACT_KPI F ON C.[YEAR] = YEAR([START_DATE]) AND C.[QUARTER] = F.[PERIOD] AND D.ID = F.KPI_ID WHERE C.THRUST_CODE IN ('Thrust 1','Thrust 2','Thrust 3','Thrust 4') )");
                //sb1.AppendLine("SELECT DISTINCT A.*,  [dbo].[udf_StripHTML] (B.REPORT_WRITEUP) as REPORT_WRITEUP FROM A LEFT JOIN REPORTWRITEUP_KPI B ON A.ID = B.KPI_ID AND A.[YEAR] = b.Year AND A.[QUARTER] = B.[PERIOD] WHERE a.[YEAR] = 2019 AND a.[QUARTER] = 'Q1'");
                // //sb1.AppendLine("select [dbo].[udf_StripHTML](REPORT_WRITEUP) as REPORT_WRITEUP ,dbo.[fn_HTMLDecode]([REPORT_WRITEUP],1,1) 'REPORT_WRITEUP1',* from REPORTWRITEUP_KPI where [YEAR] = '2019' AND PERIOD  = 'Q1' and  kpi_id in ('C33D7087-F7EC-40FE-A9A8-B2E8F341C7EB','6DAE5BF5-C766-4555-BCE2-9D941D00BCC6','89D8D44B-2E92-4328-ADB5-A1969D8BC1AA','B0337E9A-2CFA-41B1-A6E5-F9A25073BDBF','FE7EB8C9-26CD-48E9-968F-2935D01AFA41','65E07CC6-1899-45EC-877F-B4115CD76389','77162C4C-9449-470B-A2BA-74C5F201C864','C0558560-FD12-455A-9C53-C2F50B5090C4','B4D09E27-77FF-44A3-B5D1-A098AC123DC7','DBCE454A-D449-41A2-8154-8802FE7D459A','F6FFB48E-4780-4DC5-89D8-A0DE69C8E745','AEE7304B-59A5-43FF-A8A0-063AC45019B7','D01C323A-1DF5-49AB-B568-9B4B7A26444C','CBA3E940-3417-4A49-AE43-4A79C103229A','01950996-90C3-420E-98C6-4EA2F4EC2EF0','8BB7088E-3AEC-481F-B1AB-100A690C71D6','AF639E7A-BDA6-4518-BD33-7866F73EA2C9','8C25F47F-CDFF-4417-937F-080DA0D7E53B','CBD5EEB4-57D0-40F5-88EB-E5716F552024','D7FB6088-CC31-43E9-8C05-13A691750591','02D59686-7802-4B6A-AB93-73B68F35D1B8','F2C5CE32-42A2-4837-A07F-FE6AAC544BE3','A1B6FDFB-8DB3-4382-BB59-5DE14D1F1682','73670F28-A1C3-4772-837A-1F502F6F05CE','E6210F65-AC9E-4AA0-920C-30D40AB20E46','345D8E8D-1AE5-4C08-80C9-1C8998E0D5D7','8907E242-E0A1-4D32-A54C-7E48D8C4D31D','2D7E636D-47D6-4B0D-AE50-BD51FEBF9620','92F20466-E675-4E12-9248-D491B5339916','718FC072-E7E7-4BE6-8885-BAC0B854593A','EDAEA105-F625-4A7B-B0FA-BB774A9E02AC','0BDA6B25-A727-47A2-854B-8B8DFE870110','2B769517-64C3-4DB5-8CAD-F385E18F61FE','0F3EBCFC-181D-4304-B393-6DCD56681C50','211D2D68-9A4B-4EC1-B2B8-A3806331DFE1','58C31040-4677-4E67-A8BE-6DE78E63A28A')");

                sbDiv.AppendLine("<div id='MainDiv'"); //MainDiv starts here
                DataSet dsKPI = DataLayer.KPIList_SR001(Year, Quarter);

                foreach (DataRow dr in dsKPI.Tables[0].Rows)
                {
                    DataSet dsKPIDetails = DataLayer.getKPIDetails(dr["Year"].ToString(), dr["Quarter"].ToString(), dr["Kpi_Code"].ToString());

                    sbDiv.AppendLine("<div id='KPIParentDiv'>"); //KPIParentDiv starts here
                    sbDiv.AppendLine("<div id='KPIDiv'>"); // KPIDiv starts here
                    foreach (DataRow drKPI in dsKPIDetails.Tables[1].Rows)
                    {
                        sbDiv.AppendLine("<div id='divKPI'>");
                        sbDiv.AppendLine("<div id='divKPI_CODE'>" + drKPI["KPI_Code"].ToString() + "</div>");
                        sbDiv.AppendLine("<div id='divKPI_DESC'>" + drKPI["KPI_DESC"].ToString() + "</div>");
                        sbDiv.AppendLine("</div>"); //divKPI ends here

                        sbDiv.AppendLine("<div id='divTHRUST'>");
                        sbDiv.AppendLine("<div id='divTHRUST_CODE'>" + "</div>");
                        sbDiv.AppendLine("<div id='divTHRUST_DESC'>" + drKPI["THRUST_DESC"].ToString() + "</div>");

                        sbDiv.AppendLine("</div>"); //divKPI ends here
                        sbDiv.AppendLine("<div id='divINITIATIVE'>");
                        sbDiv.AppendLine("<div id='divINITIATIVE_CODE'>" + drKPI["INITIATIVE_CODE"].ToString() + "</div>");
                        sbDiv.AppendLine("<div id='divINITIATIVE_DESC'>" + drKPI["INITIATIVE_DESC"].ToString() + "</div>");

                        sbDiv.AppendLine("</div>"); //divINITIATIVE ends here
                        sbDiv.AppendLine("<div id='divSUB_INITIATIVE'>");
                        sbDiv.AppendLine("<div id='divSUB_INITIATIVE_CODE'>" + drKPI["SUB_INITIATIVE_CODE"].ToString() + "</div>");
                        sbDiv.AppendLine("<div id='divSUB_INITIATIVE_DESC'>" + drKPI["SUB_INITIATIVE_DESC"].ToString() + "</div>");
                        sbDiv.AppendLine("</div>"); //divINITIATIVE ends here
                                                    // sbDiv.AppendLine("<div id='divTHRUST_CODE'>" + drKPI["THRUST_CODE"].ToString() + "</div>");

                    }
                    sbDiv.AppendLine("</div>"); //KPIDiv ends here
                    sbDiv.AppendLine("<div id='Chart'>"); //Div chart start
                    sbDiv.AppendLine("<div id='ChartTitle'></div>");
                    sbDiv.AppendLine("<div id='divCUM_KPI_PERCENTAGE'>" + dr["CUM_KPI_PERCENTAGE"].ToString() + "</div>");
                    sbDiv.AppendLine("<div id='divCUM_KPI_TARGET'>" + dr["CUM_KPI_TARGET"].ToString() + "</div>");
                    sbDiv.AppendLine("<div id='divCUM_KPI_PROGRESS'>" + dr["CUM_KPI_PROGRESS"].ToString() + "</div>");
                    sbDiv.AppendLine("</div>"); //ReportWriteUpDiv ends here

                    sbDiv.AppendLine("<div id='DivUserName'>");
                    foreach (DataRow drUserName in dsKPIDetails.Tables[2].Rows)
                    {

                        sbDiv.AppendLine("<div id='divKPI_LEADER_NAME1'>" + drUserName["KPI_LEADER_NAME1"].ToString() + "</div>");
                        sbDiv.AppendLine("<div id='divSPONSOR_NAME'>" + drUserName["SPONSOR_NAME"].ToString() + "</div>");
                        sbDiv.AppendLine("<div id='divOWNER_NAME'>" + drUserName["OWNER_NAME"].ToString() + "</div>");
                        sbDiv.AppendLine("<div id='divOIC_NAME'>" + drUserName["OIC_NAME"].ToString() + "</div>");

                    }
                    sbDiv.AppendLine("</div>"); //UserName div ends here

                    sbDiv.AppendLine("<div id='DivDeliveries'>");
                    sbDiv.AppendLine("<div id='DivDeliveriesTitle'>Deliverables</div>");
                    foreach (DataRow drDeli in dsKPIDetails.Tables[0].Rows)
                    {
                        sbDiv.AppendLine("<div id='DivByEachYear'>");
                        sbDiv.AppendLine("<div id='divYear'>" + drDeli["Year"].ToString() + "</div>");
                        string[] words = drDeli["P_T"].ToString().Split('/');
                        if (words.Length == 2)
                        {
                            sbDiv.AppendLine("<div id='div_Deliverable_Progress'>" + words[0].ToString() + "</div>");
                            sbDiv.AppendLine("<div id='div_Deliverable_Target'>" + words[1].ToString() + "</div>");

                        }
                        if (words.Length == 1)
                        {
                            sbDiv.AppendLine("<div id='div_Deliverable_Progress'>" + words[0].ToString() + "</div>");
                            sbDiv.AppendLine("<div id='div_Deliverable_Target'>" + "0" + "</div>");
                        }
                        else
                        {
                            sbDiv.AppendLine("<div id='div_Deliverable_Progress'>" + "0" + "</div>");
                            sbDiv.AppendLine("<div id='div_Deliverable_Target'>" + "0" + "</div>");
                        }

                        sbDiv.AppendLine("<div id='divDesc'>" + drDeli["DESC"].ToString() + "</div>");
                        sbDiv.AppendLine("</div>");

                    }
                    sbDiv.AppendLine("</div>"); //Deliveries div ends here

                    sbDiv.AppendLine("<div id='ReportWriteUpDiv'>");
                    sbDiv.AppendLine("<div id='ReportWriteUpTitle'>Progress Report as of " + Quarter + " " + Year + "</div>");
                    sbDiv.AppendLine("<div id='divREPORT_WRITEUP'>" + dr["REPORT_WRITEUP"].ToString() + "</div>");
                    sbDiv.AppendLine("</div>"); //ReportWriteUpDiv ends here
                    sbDiv.AppendLine("</div>"); //Parent Div End here
                }

                sbDiv.AppendLine("</div>"); //Main div end here

                return sbDiv.ToString();
            }

            catch (Exception ex)
            {
                throw ex;
            }

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                //divReports.InnerHtml = GetReportsHTML(ddlYear.Text, ddlQuarter.SelectedItem.ToString());
                string innerHtml = GetReportsHTML(ddlYear.Text, ddlQuarter.SelectedItem.ToString());
                // win.open('data:text/html;charset=utf-8,text%20to%20show');

                Session["HTML"] = innerHtml.ToString();

                ScriptManager.RegisterStartupScript(Page, typeof(Page), "OpenWindow", "window.open('Popup.aspx');", true);

            }
            catch (Exception ex)
            {
                //Display error msg
            }
        }
    }
}