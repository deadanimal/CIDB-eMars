﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MAT.WebApp.App.Reports
{
    public partial class SL04_005 : WebApp.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}